KEY STONE FREE WEBSITE
1. Open index.html in a browser to preview.
2. This is a static, mobile-friendly website with English, Sinhala and Arabic language switching.
3. Contact form opens WhatsApp to +971553628307; it does not store submissions.
4. To publish free: create a GitHub account, create a repository, upload index.html, then enable GitHub Pages in Settings > Pages. Your site will receive a free github.io address.
5. Before publishing, verify the exact registered legal company name and service details. Replace any wording that does not accurately reflect licensed services.

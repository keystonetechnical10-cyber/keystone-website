KEY STONE WEBSITE UPDATE
1. Upload index.html and logo.jpeg to the root of your GitHub repository.
2. If asked, choose Commit changes to the main branch.
3. GitHub Pages will redeploy; refresh the published site after a few minutes.
4. Forms open WhatsApp with the entered details. Selected documents are NOT uploaded or stored by this static site; customers must attach them manually in WhatsApp.
5. To securely receive and store documents, connect a backend/form service before collecting sensitive documents.
